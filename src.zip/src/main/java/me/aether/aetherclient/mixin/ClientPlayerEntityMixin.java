package me.aether.aetherclient.mixin;

import me.aether.aetherclient.rotation.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void aether$beforeTick(CallbackInfo ci) {
        RotationManager.update(MinecraftClient.getInstance());
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void aether$beforeSend(CallbackInfo ci) {
        RotationManager.setSendingPacket(true);
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void aether$afterSend(CallbackInfo ci) {
        RotationManager.setSendingPacket(false);
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void aether$afterTick(CallbackInfo ci) {
        if (RotationManager.isActive()) {
            ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
            self.setBodyYaw(RotationManager.getYaw());
            self.setHeadYaw(RotationManager.getYaw());
        }
    }
}
