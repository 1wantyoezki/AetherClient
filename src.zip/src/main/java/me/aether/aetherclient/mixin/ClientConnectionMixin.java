package me.aether.aetherclient.mixin;

import me.aether.aetherclient.rotation.RotationManager;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @ModifyVariable(method = "send(Lnet/minecraft/network/packet/Packet;)V",
                    at = @At("HEAD"), argsOnly = true)
    private Packet<?> aether$modifySend(Packet<?> packet) {
        if (!RotationManager.isActive()) return packet;

        if (packet instanceof PlayerMoveC2SPacket pm) {
            if (pm.changesLook()) {
                return new PlayerMoveC2SPacket.LookAndOnGround(
                        RotationManager.getYaw(),
                        RotationManager.getPitch(),
                        pm.isOnGround(),
                        pm.horizontalCollision()
                );
            }
        }
        return packet;
    }
}
