package me.aether.aetherclient.mixin;

import me.aether.aetherclient.module.KeybindHandler;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void aether$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action == 1) {
            KeybindHandler.onKeyPressed(key);
        } else if (action == 0) {
            KeybindHandler.onKeyReleased(key);
        }
    }
}
