package me.aether.aetherclient.mixin;

import me.aether.aetherclient.rotation.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getYaw", at = @At("HEAD"), cancellable = true)
    private void aether$getYaw(CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ClientPlayerEntity && RotationManager.isSendingPacket()) {
            cir.setReturnValue(RotationManager.getYaw());
        }
    }

    @Inject(method = "getPitch", at = @At("HEAD"), cancellable = true)
    private void aether$getPitch(CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ClientPlayerEntity && RotationManager.isSendingPacket()) {
            cir.setReturnValue(RotationManager.getPitch());
        }
    }
}
