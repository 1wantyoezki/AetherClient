package me.aether.aetherclient.gui;

import me.aether.aetherclient.module.Category;
import me.aether.aetherclient.module.ChoiceSetting;
import me.aether.aetherclient.module.KeybindHandler;
import me.aether.aetherclient.module.Module;
import me.aether.aetherclient.module.ModuleManager;
import me.aether.aetherclient.module.Setting;
import me.aether.aetherclient.module.SliderSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private Category selectedCategory = Category.COMBAT;
    private String searchQuery = "";
    private boolean searchActive = false;
    private Module openSettings = null;

    private int panelX, panelY, panelW, panelH;
    private int setX, setY, setW, setH;

    private final int sidebarW = 50;
    private final int headerH = 19;
    private final int rowH = 14;
    private final int padding = 5;
    private final int settingsW = 165;

    private int scrollOffset = 0;
    private int draggingSlider = -1;
    private int settingsScroll = 0;

    public ClickGuiScreen() {
        super(Text.literal("AetherClient"));
    }

    @Override
    protected void init() {
        panelW = Math.min(300, this.width - 20);
        panelH = Math.min(180, this.height - 20);

        if (openSettings != null) {
            int gap = 8;
            int totalW = settingsW + gap + panelW;
            int startX = (this.width - totalW) / 2;
            if (startX < 8) startX = 8;
            setX = startX;
            setY = (this.height - panelH) / 2;
            setW = settingsW;
            setH = panelH;
            panelX = startX + settingsW + gap;
            panelY = setY;
        } else {
            panelX = (this.width - panelW) / 2;
            panelY = (this.height - panelH) / 2;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Основная панель
        RenderUtils.roundedRect(ctx, panelX, panelY, panelW, panelH, 20, Theme.PANEL_BG);
        RenderUtils.roundedRect(ctx, panelX, panelY, sidebarW, panelH, 20, Theme.SIDEBAR_BG);

        String title = "AetherClient";
        int titleWidth = RenderUtils.width(this.textRenderer, title);
        int contentX = panelX + sidebarW;
        int contentW = panelW - sidebarW;
        int titleX = contentX + (contentW - titleWidth) / 2;
        int titleY = panelY + 6;
        RenderUtils.glowText(ctx, this.textRenderer, title, titleX, titleY,
                Theme.TEXT, Theme.ACCENT, true);

        int searchW = 74;
        int searchH = 12;
        int searchX = panelX + panelW - searchW - padding;
        int searchY = panelY + 5;
        RenderUtils.roundedRect(ctx, searchX, searchY, searchW, searchH, 20, Theme.SEARCH_BG);

        String searchDisplay = (searchQuery.isEmpty() && !searchActive) ? "Search..." : searchQuery;
        int searchTextColor = (searchQuery.isEmpty() && !searchActive) ? Theme.TEXT_DESC : Theme.TEXT;
        int searchTextY = searchY + (searchH - 8) / 2;
        RenderUtils.text(ctx, this.textRenderer, searchDisplay, searchX + 6, searchTextY, searchTextColor, false);

        if (searchActive && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cursorX = searchX + 6 + RenderUtils.width(this.textRenderer, searchQuery) + 1;
            ctx.fill(cursorX, searchY + 3, cursorX + 1, searchY + searchH - 3, Theme.CURSOR);
        }

        int catY = panelY + headerH + 3;
        for (Category c : Category.values()) {
            boolean sel = (c == selectedCategory) && searchQuery.isEmpty();
            int catX = panelX + 4;
            int catW = sidebarW - 8;
            int catH = 14;

            if (sel) {
                RenderUtils.roundedRect(ctx, catX, catY, catW, catH, 20, Theme.ACCENT);
            } else if (isHover(mouseX, mouseY, catX, catY, catW, catH)) {
                RenderUtils.roundedRect(ctx, catX, catY, catW, catH, 20, Theme.ROW_HOVER);
            }

            int textColor = sel ? 0xFFFFFFFF : Theme.TEXT_DIM;
            int textY = catY + (catH - 8) / 2;
            RenderUtils.text(ctx, this.textRenderer, c.displayName, catX + 9, textY, textColor, false);

            catY += catH + 2;
        }

        int listX = panelX + sidebarW + padding;
        int listY = panelY + headerH + 3;
        int listW = panelW - sidebarW - padding * 2;
        int listH = panelH - headerH - 3 - padding;

        List<Module> modules = searchQuery.isEmpty()
                ? ModuleManager.byCategory(selectedCategory)
                : ModuleManager.search(searchQuery);

        int rowY = listY - scrollOffset;
        for (Module m : modules) {
            if (rowY + rowH < listY) { rowY += rowH + 1; continue; }
            if (rowY > listY + listH) break;

            boolean hover = isHover(mouseX, mouseY, listX, rowY, listW, rowH)
                    && mouseY >= listY && mouseY <= listY + listH;

            int bgColor = m.enabled ? Theme.ROW_ENABLED : Theme.ROW_BG;
            if (hover) bgColor = Theme.ROW_HOVER;
            RenderUtils.roundedRect(ctx, listX, rowY, listW, rowH, 20, bgColor);

            int cbSize = 8;
            int cbX = listX + 5;
            int cbY = rowY + (rowH - cbSize) / 2;
            RenderUtils.roundedRect(ctx, cbX, cbY, cbSize, cbSize, 20,
                    m.enabled ? Theme.ACCENT : Theme.CHECKBOX_OFF);

            int nameX = cbX + cbSize + 5;
            int nameY = rowY + (rowH - 8) / 2;
            RenderUtils.text(ctx, this.textRenderer, m.name, nameX, nameY, Theme.TEXT, false);

            String right;
            if (m.binding) {
                right = "[...]";
            } else if (m.keybind != -1) {
                right = GLFW.glfwGetKeyName(m.keybind, 0);
                if (right == null) right = "KEY" + m.keybind;
            } else {
                right = m.getDisplayInfo();
            }
            if (right != null && !right.isEmpty()) {
                int rw = RenderUtils.width(this.textRenderer, right);
                int rx = listX + listW - rw - 8;
                if (rx > nameX + 60) {
                    RenderUtils.text(ctx, this.textRenderer, right, rx, nameY, Theme.TEXT_DESC, false);
                }
            }

            rowY += rowH + 1;
        }

        // Панель настроек слева
        if (openSettings != null) renderSettings(ctx, mouseX, mouseY);
    }

    private void renderSettings(DrawContext ctx, int mouseX, int mouseY) {
        RenderUtils.roundedRect(ctx, setX, setY, setW, setH, 20, Theme.PANEL_BG);

        String title = openSettings.name;
        int tw = RenderUtils.width(this.textRenderer, title);
        RenderUtils.glowText(ctx, this.textRenderer, title,
                setX + (setW - tw) / 2, setY + 6,
                Theme.TEXT, Theme.ACCENT, true);

        int y = setY + 24 - settingsScroll;
        int minY = setY + 22;
        int maxY = setY + setH - 6;

        for (int i = 0; i < openSettings.getSettings().size(); i++) {
            Setting s = openSettings.getSettings().get(i);
            int sy = y + i * 24;

            if (sy + 20 < minY || sy > maxY) continue;

            if (s instanceof SliderSetting sl) {
                RenderUtils.text(ctx, this.textRenderer, s.name,
                        setX + 6, sy, Theme.TEXT_DIM, false);
                String val = s.displayValue();
                int vw = RenderUtils.width(this.textRenderer, val);
                RenderUtils.text(ctx, this.textRenderer, val,
                        setX + setW - 6 - vw, sy, Theme.TEXT, false);

                int barX = setX + 6;
                int barY = sy + 12;
                int barW = setW - 12;
                int barH = 4;

                RenderUtils.roundedRect(ctx, barX, barY, barW, barH, barH / 2, Theme.ROW_BG);
                int fillW = (int)(barW * sl.getPercent());
                if (fillW > 0) {
                    RenderUtils.roundedRect(ctx, barX, barY, fillW, barH, barH / 2, Theme.ACCENT);
                }
                int hx = barX + fillW;
                RenderUtils.roundedRect(ctx, hx - 3, barY - 3, 6, 10, 3, 0xFFFFFFFF);
            } else if (s instanceof ChoiceSetting cs) {
                RenderUtils.text(ctx, this.textRenderer, s.name,
                        setX + 6, sy + 2, Theme.TEXT_DIM, false);
                String val = s.displayValue();
                int vw = RenderUtils.width(this.textRenderer, val);
                int bx = setX + setW - vw - 16;
                int bw = vw + 10;
                int bh = 13;
                boolean hover = mouseX >= bx && mouseX < bx + bw && mouseY >= sy && mouseY < sy + bh;
                int c = hover ? Theme.ROW_HOVER : Theme.ROW_BG;
                RenderUtils.roundedRect(ctx, bx, sy, bw, bh, bh / 2, c);
                RenderUtils.text(ctx, this.textRenderer, val,
                        bx + 5, sy + 3, Theme.TEXT, false);
            }
        }
    }

    private boolean isHover(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Поиск
        int searchW = 74;
        int searchH = 12;
        int searchX = panelX + panelW - searchW - padding;
        int searchY = panelY + 5;

        if (button == 0) {
            if (isHover((int) mx, (int) my, searchX, searchY, searchW, searchH)) {
                searchActive = true;
                return true;
            } else {
                searchActive = false;
            }
        }

        // Категории
        int catY = panelY + headerH + 3;
        for (Category c : Category.values()) {
            int catX = panelX + 4;
            int catW = sidebarW - 8;
            int catH = 14;
            if (isHover((int) mx, (int) my, catX, catY, catW, catH)) {
                selectedCategory = c;
                searchQuery = "";
                scrollOffset = 0;
                return true;
            }
            catY += catH + 2;
        }

        // Клик по настройкам
        if (openSettings != null) {
            int y = setY + 24 - settingsScroll;
            for (int i = 0; i < openSettings.getSettings().size(); i++) {
                Setting s = openSettings.getSettings().get(i);
                int sy = y + i * 24;

                if (s instanceof SliderSetting sl) {
                    int barX = setX + 6;
                    int barY = sy + 12;
                    int barW = setW - 12;
                    if (mx >= barX && mx <= barX + barW && my >= barY - 5 && my <= barY + 10) {
                        draggingSlider = i;
                        float p = (float)((mx - barX) / barW);
                        p = Math.max(0f, Math.min(1f, p));
                        sl.setFromPercent(p);
                        return true;
                    }
                } else if (s instanceof ChoiceSetting cs) {
                    String val = s.displayValue();
                    int vw = RenderUtils.width(this.textRenderer, val);
                    int bx = setX + setW - vw - 16;
                    int bw = vw + 10;
                    int bh = 13;
                    if (mx >= bx && mx < bx + bw && my >= sy && my < sy + bh) {
                        cs.next();
                        return true;
                    }
                }
            }
        }

        // Модули
        int listX = panelX + sidebarW + padding;
        int listY = panelY + headerH + 3;
        int listW = panelW - sidebarW - padding * 2;
        int listH = panelH - headerH - 3 - padding;

        List<Module> modules = searchQuery.isEmpty()
                ? ModuleManager.byCategory(selectedCategory)
                : ModuleManager.search(searchQuery);

        int rowY = listY - scrollOffset;
        for (Module m : modules) {
            if (my >= listY && my <= listY + listH
                    && isHover((int) mx, (int) my, listX, rowY, listW, rowH)) {

                if (button == 0) {
                    if (KeybindHandler.isBinding()) return true;
                    m.onClick();
                } else if (button == 1) {
                    if (openSettings == m) {
                        openSettings = null;
                        init();
                    } else {
                        openSettings = m;
                        settingsScroll = 0;
                        init();
                    }
                } else if (button == 2) {
                    KeybindHandler.startBinding(m);
                }
                return true;
            }
            rowY += rowH + 1;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingSlider >= 0) {
            Setting s = openSettings.getSettings().get(draggingSlider);
            if (s instanceof SliderSetting sl) {
                int barX = setX + 6;
                int barW = setW - 12;
                float p = (float)((mx - barX) / barW);
                p = Math.max(0f, Math.min(1f, p));
                sl.setFromPercent(p);
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingSlider = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        int listY = panelY + headerH + 3;
        int listH = panelH - headerH - 3 - padding;
        if (my >= listY && my <= listY + listH
                && mx >= panelX + sidebarW && mx <= panelX + panelW) {
            scrollOffset -= (int) (vAmount * 16);
            if (scrollOffset < 0) scrollOffset = 0;
            return true;
        }
        if (openSettings != null && mx >= setX && mx <= setX + setW
                && my >= setY && my <= setY + setH) {
            settingsScroll -= (int) (vAmount * 12);
            if (settingsScroll < 0) settingsScroll = 0;
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchActive && !Character.isISOControl(chr)) {
            if (searchQuery.length() < 40) {
                searchQuery += chr;
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (KeybindHandler.isBinding()) {
                KeybindHandler.cancelBinding();
                return true;
            }
            if (searchActive) {
                searchActive = false;
                searchQuery = "";
                return true;
            }
            if (openSettings != null) {
                openSettings = null;
                init();
                return true;
            }
            this.close();
            return true;
        }
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchQuery.isEmpty()) {
                    searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                searchActive = false;
                return true;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
