package me.aether.aetherclient.gui;

import me.aether.aetherclient.module.Category;
import me.aether.aetherclient.module.Module;
import me.aether.aetherclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private Category selectedCategory = Category.COMBAT;
    private String searchQuery = "";
    private boolean searchActive = false;

    private int panelX, panelY, panelW, panelH;
    private final int sidebarW = 50;
    private final int headerH = 19;
    private final int rowH = 14;
    private final int padding = 5;

    private int scrollOffset = 0;

    public ClickGuiScreen() {
        super(Text.literal("AetherClient"));
    }

    @Override
    protected void init() {
        panelW = Math.min(300, this.width - 20);
        panelH = Math.min(180, this.height - 20);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int panelRadius = 18;
        int rowRadius = 7;

        // Панель и сайдбар — крупные радиусы
        RenderUtils.roundedRect(ctx, panelX, panelY, panelW, panelH, panelRadius, Theme.PANEL_BG);
        RenderUtils.roundedRect(ctx, panelX, panelY, sidebarW, panelH, panelRadius, Theme.SIDEBAR_BG);

        String title = "AetherClient";
        int titleWidth = RenderUtils.width(this.textRenderer, title);
        int contentX = panelX + sidebarW;
        int contentW = panelW - sidebarW;
        int titleX = contentX + (contentW - titleWidth) / 2;
        int titleY = panelY + 6;
        RenderUtils.glowText(ctx, this.textRenderer, title, titleX, titleY,
                Theme.TEXT, Theme.ACCENT, true);

        int searchW = 74;
        int searchH = 12;
        int searchX = panelX + panelW - searchW - padding;
        int searchY = panelY + 5;
        RenderUtils.roundedRect(ctx, searchX, searchY, searchW, searchH, searchH / 2, Theme.SEARCH_BG);

        String searchDisplay = (searchQuery.isEmpty() && !searchActive) ? "Search..." : searchQuery;
        int searchTextColor = (searchQuery.isEmpty() && !searchActive) ? Theme.TEXT_DESC : Theme.TEXT;
        int searchTextY = searchY + (searchH - 8) / 2;
        RenderUtils.text(ctx, this.textRenderer, searchDisplay, searchX + 6, searchTextY, searchTextColor, false);

        if (searchActive && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cursorX = searchX + 6 + RenderUtils.width(this.textRenderer, searchQuery) + 1;
            ctx.fill(cursorX, searchY + 3, cursorX + 1, searchY + searchH - 3, Theme.CURSOR);
        }

        // Категории — полностью круглые боковины
        int catY = panelY + headerH + 3;
        for (Category c : Category.values()) {
            boolean sel = (c == selectedCategory) && searchQuery.isEmpty();
            int catX = panelX + 4;
            int catW = sidebarW - 8;
            int catH = 14;
            int cr = catH / 2;

            if (sel) {
                RenderUtils.roundedRect(ctx, catX, catY, catW, catH, cr, Theme.ACCENT);
            } else if (isHover(mouseX, mouseY, catX, catY, catW, catH)) {
                RenderUtils.roundedRect(ctx, catX, catY, catW, catH, cr, Theme.ROW_HOVER);
            }

            int textColor = sel ? 0xFFFFFFFF : Theme.TEXT_DIM;
            int textY = catY + (catH - 8) / 2;
            RenderUtils.text(ctx, this.textRenderer, c.displayName, catX + 9, textY, textColor, false);

            catY += catH + 2;
        }

        int listX = panelX + sidebarW + padding;
        int listY = panelY + headerH + 3;
        int listW = panelW - sidebarW - padding * 2;
        int listH = panelH - headerH - 3 - padding;

        List<Module> modules = searchQuery.isEmpty()
                ? ModuleManager.byCategory(selectedCategory)
                : ModuleManager.search(searchQuery);

        int rowY = listY - scrollOffset;
        for (Module m : modules) {
            if (rowY + rowH < listY) {
                rowY += rowH + 1;
                continue;
            }
            if (rowY > listY + listH) break;

            boolean hover = isHover(mouseX, mouseY, listX, rowY, listW, rowH)
                    && mouseY >= listY && mouseY <= listY + listH;

            int bgColor = m.enabled ? Theme.ROW_ENABLED : Theme.ROW_BG;
            if (hover) bgColor = Theme.ROW_HOVER;
            RenderUtils.roundedRect(ctx, listX, rowY, listW, rowH, rowRadius, bgColor);

            // Чекбокс — полностью круг
            int cbSize = 8;
            int cbX = listX + 5;
            int cbY = rowY + (rowH - cbSize) / 2;
            RenderUtils.roundedRect(ctx, cbX, cbY, cbSize, cbSize, cbSize / 2,
                    m.enabled ? Theme.ACCENT : Theme.CHECKBOX_OFF);

            int nameX = cbX + cbSize + 5;
            int nameY = rowY + (rowH - 8) / 2;
            RenderUtils.text(ctx, this.textRenderer, m.name, nameX, nameY, Theme.TEXT, false);

            String right = !m.getDisplayInfo().isEmpty() ? m.getDisplayInfo() : m.description;
            int rightW = RenderUtils.width(this.textRenderer, right);
            int rightX = listX + listW - rightW - 8;
            if (rightX > nameX + 60) {
                RenderUtils.text(ctx, this.textRenderer, right, rightX, nameY, Theme.TEXT_DESC, false);
            }

            rowY += rowH + 1;
        }
    }

    private boolean isHover(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        int searchW = 74;
        int searchH = 12;
        int searchX = panelX + panelW - searchW - padding;
        int searchY = panelY + 5;
        if (isHover((int) mx, (int) my, searchX, searchY, searchW, searchH)) {
            searchActive = true;
            return true;
        } else {
            searchActive = false;
        }

        int catY = panelY + headerH + 3;
        for (Category c : Category.values()) {
            int catX = panelX + 4;
            int catW = sidebarW - 8;
            int catH = 14;
            if (isHover((int) mx, (int) my, catX, catY, catW, catH)) {
                selectedCategory = c;
                searchQuery = "";
                scrollOffset = 0;
                return true;
            }
            catY += catH + 2;
        }

        int listX = panelX + sidebarW + padding;
        int listY = panelY + headerH + 3;
        int listW = panelW - sidebarW - padding * 2;
        int listH = panelH - headerH - 3 - padding;

        List<Module> modules = searchQuery.isEmpty()
                ? ModuleManager.byCategory(selectedCategory)
                : ModuleManager.search(searchQuery);

        int rowY = listY - scrollOffset;
        for (Module m : modules) {
            if (my >= listY && my <= listY + listH
                    && isHover((int) mx, (int) my, listX, rowY, listW, rowH)) {
                m.onClick();
                return true;
            }
            rowY += rowH + 1;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        int listY = panelY + headerH + 3;
        int listH = panelH - headerH - 3 - padding;
        if (my >= listY && my <= listY + listH) {
            scrollOffset -= (int) (vAmount * 16);
            if (scrollOffset < 0) scrollOffset = 0;
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchActive && !Character.isISOControl(chr)) {
            if (searchQuery.length() < 40) {
                searchQuery += chr;
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (searchActive) {
                searchActive = false;
                searchQuery = "";
                return true;
            }
            this.close();
            return true;
        }
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!searchQuery.isEmpty()) {
                    searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                searchActive = false;
                return true;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
