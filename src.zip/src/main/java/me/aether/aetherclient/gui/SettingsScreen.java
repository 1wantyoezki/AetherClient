package me.aether.aetherclient.gui;

import me.aether.aetherclient.module.ChoiceSetting;
import me.aether.aetherclient.module.Module;
import me.aether.aetherclient.module.Setting;
import me.aether.aetherclient.module.SliderSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {
    private final Module module;
    private final ClickGuiScreen parent;

    private int panelX, panelY, panelW, panelH;
    private int draggingSlider = -1;
    private final int padding = 6;
    private final int rowH = 20;

    public SettingsScreen(Module module, ClickGuiScreen parent) {
        super(Text.literal(module.name));
        this.module = module;
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelW = 200;
        panelH = 30 + module.getSettings().size() * (rowH + 4) + 10;
        panelH = Math.min(panelH, this.height - 20);
        panelX = (this.width - panelW) / 2 - 160;
        panelY = (this.height - panelH) / 2;
        if (panelX < 10) panelX = 10;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        RenderUtils.roundedRect(ctx, panelX, panelY, panelW, panelH, 14, Theme.PANEL_BG);

        String title = module.name;
        int tw = RenderUtils.width(this.textRenderer, title);
        RenderUtils.glowText(ctx, this.textRenderer, title,
                panelX + (panelW - tw) / 2, panelY + 6,
                Theme.TEXT, Theme.ACCENT, true);

        int y = panelY + 24;
        for (int i = 0; i < module.getSettings().size(); i++) {
            Setting s = module.getSettings().get(i);
            int sy = y + i * (rowH + 4);

            if (s instanceof SliderSetting sl) {
                RenderUtils.text(ctx, this.textRenderer, s.name,
                        panelX + padding, sy, Theme.TEXT_DIM, false);
                String val = s.displayValue();
                int vw = RenderUtils.width(this.textRenderer, val);
                RenderUtils.text(ctx, this.textRenderer, val,
                        panelX + panelW - padding - vw, sy, Theme.TEXT, false);

                int barX = panelX + padding;
                int barY = sy + 11;
                int barW = panelW - padding * 2;
                int barH = 4;

                RenderUtils.roundedRect(ctx, barX, barY, barW, barH, barH / 2, Theme.ROW_BG);
                int fillW = (int)(barW * sl.getPercent());
                if (fillW > 0) {
                    RenderUtils.roundedRect(ctx, barX, barY, fillW, barH, barH / 2, Theme.ACCENT);
                }
                int hx = barX + fillW;
                RenderUtils.roundedRect(ctx, hx - 3, barY - 3, 6, 10, 3, 0xFFFFFFFF);
            } else if (s instanceof ChoiceSetting cs) {
                RenderUtils.text(ctx, this.textRenderer, s.name,
                        panelX + padding, sy, Theme.TEXT_DIM, false);
                String val = s.displayValue();
                int vw = RenderUtils.width(this.textRenderer, val);
                int bx = panelX + panelW - padding - vw - 10;
                int bw = vw + 10;
                int bh = 14;
                boolean hover = mouseX >= bx && mouseX < bx + bw && mouseY >= sy - 2 && mouseY < sy + bh;
                int c = hover ? Theme.ROW_HOVER : Theme.ROW_BG;
                RenderUtils.roundedRect(ctx, bx, sy - 2, bw, bh, bh / 2, c);
                RenderUtils.text(ctx, this.textRenderer, val,
                        bx + 5, sy + 1, Theme.TEXT, false);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        int y = panelY + 24;
        for (int i = 0; i < module.getSettings().size(); i++) {
            Setting s = module.getSettings().get(i);
            int sy = y + i * (rowH + 4);

            if (s instanceof SliderSetting sl) {
                int barX = panelX + padding;
                int barY = sy + 11;
                int barW = panelW - padding * 2;
                if (mx >= barX && mx <= barX + barW && my >= barY - 5 && my <= barY + 8) {
                    draggingSlider = i;
                    sl.setFromPercent((float)((mx - barX) / barW));
                    return true;
                }
            } else if (s instanceof ChoiceSetting cs) {
                String val = s.displayValue();
                int vw = RenderUtils.width(this.textRenderer, val);
                int bx = panelX + panelW - padding - vw - 10;
                int bw = vw + 10;
                int bh = 14;
                if (mx >= bx && mx < bx + bw && my >= sy - 2 && my < sy + bh) {
                    cs.next();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingSlider >= 0) {
            Setting s = module.getSettings().get(draggingSlider);
            if (s instanceof SliderSetting sl) {
                int barX = panelX + padding;
                int barW = panelW - padding * 2;
                float p = (float)((mx - barX) / barW);
                p = Math.max(0f, Math.min(1f, p));
                sl.setFromPercent(p);
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingSlider = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
