package me.aether.aetherclient.gui;

import net.minecraft.util.Identifier;

public class Theme {
    public static int ACCENT = 0xFFEF4444;

    public static final Identifier FONT = Identifier.of("aetherclient", "aether");

    public static final int PANEL_BG     = 0xE8121216;
    public static final int SIDEBAR_BG   = 0xF00D0D10;
    public static final int ROW_BG       = 0x18FFFFFF;
    public static final int ROW_HOVER    = 0x30FFFFFF;
    public static final int ROW_ENABLED  = 0x30FF5C5C;
    public static final int TEXT         = 0xFFFFFFFF;
    public static final int TEXT_DIM     = 0xFFB0B0B0;
    public static final int TEXT_DESC    = 0xFF7A7A7A;
    public static final int SEARCH_BG    = 0x40000000;
    public static final int CURSOR       = 0xFFFFFFFF;
    public static final int CHECKBOX_OFF = 0x40FFFFFF;
}
