package me.aether.aetherclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class RenderUtils {

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(s);
    }

    /**
     * Скруглённый прямоугольник с антиалиасингом.
     * Каждый пиксель угла рисуется ОТДЕЛЬНО со своей альфой — без дырок.
     */
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;

        int maxR = Math.min(w / 2, h / 2);
        if (r > maxR) r = maxR;

        int a = (color >>> 24) & 0xFF;
        int rgb = color & 0x00FFFFFF;

        // Центр — заливка сплошным
        ctx.fill(x + r, y, x + w - r, y + h, color);

        // Бока — сплошная заливка (только между скруглениями)
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        // Углы — 4 квадрата r×r, каждый пиксель со своей альфой
        for (int dy = 0; dy < r; dy++) {
            for (int dx = 0; dx < r; dx++) {
                // расстояние от центра дуги
                double cx = r - 0.5 - dx;
                double cy = r - 0.5 - dy;
                double dist = Math.sqrt(cx * cx + cy * cy);

                // покрытие: 1.0 = полностью внутри, 0.0 = снаружи
                double coverage = r - dist + 0.5;
                if (coverage <= 0) continue;
                if (coverage > 1) coverage = 1;

                int pa = (int) (a * coverage);
                if (pa <= 0) continue;
                int c = (pa << 24) | rgb;

                // Верх-лево
                ctx.fill(x + dx, y + dy, x + dx + 1, y + dy + 1, c);
                // Верх-право
                ctx.fill(x + w - 1 - dx, y + dy, x + w - dx, y + dy + 1, c);
                // Низ-лево
                ctx.fill(x + dx, y + h - 1 - dy, x + dx + 1, y + h - dy, c);
                // Низ-право
                ctx.fill(x + w - 1 - dx, y + h - 1 - dy, x + w - dx, y + h - dy, c);
            }
        }
    }

    public static void text(DrawContext ctx, TextRenderer tr, String s,
                            int x, int y, int color, boolean shadow) {
        ctx.drawText(tr, s, x, y, color, shadow);
    }

    public static void glowText(DrawContext ctx, TextRenderer tr, String s,
                                int x, int y, int textColor, int glowColor, boolean shadow) {
        int[][] off = {
                {-2,0},{2,0},{0,-2},{0,2},
                {-1,-1},{1,-1},{-1,1},{1,1},
                {-2,-2},{2,-2},{-2,2},{2,2}
        };
        for (int[] o : off) ctx.drawText(tr, s, x + o[0], y + o[1], glowColor, false);
        ctx.drawText(tr, s, x, y, textColor, shadow);
    }
}
