package me.aether.aetherclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public class RenderUtils {

    public static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(Theme.FONT));
    }

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(styled(s));
    }

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w / 2, h / 2));
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }

        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            double dx = r - Math.sqrt(r * r - dy * dy);
            int d = (int) Math.ceil(dx);
            if (d < 0) d = 0;
            int topY = y + i;
            int botY = y + h - i - 1;
            ctx.fill(x + d, topY, x + r, topY + 1, color);
            ctx.fill(x + w - r, topY, x + w - d, topY + 1, color);
            ctx.fill(x + d, botY, x + r, botY + 1, color);
            ctx.fill(x + w - r, botY, x + w - d, botY + 1, color);
        }
    }

    public static void text(DrawContext ctx, TextRenderer tr, String s,
                            int x, int y, int color, boolean shadow) {
        ctx.drawText(tr, styled(s), x, y, color, shadow);
    }

    public static void glowText(DrawContext ctx, TextRenderer tr, String s,
                                int x, int y, int textColor, int glowColor, boolean shadow) {
        Text t = styled(s);
        int[][] offsets = {
                {-2, 0}, {2, 0}, {0, -2}, {0, 2},
                {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
                {-2, -2}, {2, -2}, {-2, 2}, {2, 2}
        };
        for (int[] o : offsets) {
            ctx.drawText(tr, t, x + o[0], y + o[1], glowColor, false);
        }
        ctx.drawText(tr, t, x, y, textColor, shadow);
    }
}
