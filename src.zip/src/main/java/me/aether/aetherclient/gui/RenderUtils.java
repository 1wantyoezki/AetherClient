package me.aether.aetherclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public class RenderUtils {

    public static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(Theme.FONT));
    }

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(styled(s));
    }

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        int maxR = Math.min(w / 2, h / 2);
        if (r > maxR) r = maxR;
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }

        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        for (int dy = 0; dy < r; dy++) {
            double yDist = r - dy - 0.5;
            double xDistMax = Math.sqrt(r * r - yDist * yDist);
            int pixels = (int) Math.floor(xDistMax + 0.5);
            int startX = r - pixels;
            if (startX < 0) startX = 0;
            ctx.fill(x + startX, y + dy, x + r, y + dy + 1, color);
            ctx.fill(x + w - r, y + dy, x + w - startX, y + dy + 1, color);
            ctx.fill(x + startX, y + h - dy - 1, x + r, y + h - dy, color);
            ctx.fill(x + w - r, y + h - dy - 1, x + w - startX, y + h - dy, color);
        }
    }

    public static void text(DrawContext ctx, TextRenderer tr, String s,
                            int x, int y, int color, boolean shadow) {
        ctx.drawText(tr, styled(s), x, y, color, shadow);
    }

    public static void glowText(DrawContext ctx, TextRenderer tr, String s,
                                int x, int y, int textColor, int glowColor, boolean shadow) {
        Text t = styled(s);
        int[][] offsets = {
                {-2, 0}, {2, 0}, {0, -2}, {0, 2},
                {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
                {-2, -2}, {2, -2}, {-2, 2}, {2, 2}
        };
        for (int[] o : offsets) {
            ctx.drawText(tr, t, x + o[0], y + o[1], glowColor, false);
        }
        ctx.drawText(tr, t, x, y, textColor, shadow);
    }
}
