package me.aether.aetherclient.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public class RenderUtils {

    public static Text styled(String s) {
        return Text.literal(s).setStyle(Style.EMPTY.withFont(Theme.FONT));
    }

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(styled(s));
    }

    /**
     * Рисует прямоугольник со скруглёнными углами и сглаженными краями.
     * r — радиус в пикселях. Чем больше — тем круглее.
     * Для "полностью круглых" боков: r = h/2.
     */
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        int maxR = Math.min(w / 2, h / 2);
        if (r > maxR) r = maxR;
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }

        int alpha = (color >>> 24) & 0xFF;
        int rgb = color & 0x00FFFFFF;

        // Центральные полосы (без углов)
        ctx.fill(x + r, y, x + w - r, y + h, color);

        // Левый и правый боковые прямоугольники
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);

        // Четыре угла — рисуем по одному пикселю с альфа-сглаживанием
        for (int dy = 0; dy < r; dy++) {
            double yDist = r - dy - 0.5;
            double xDist = Math.sqrt(Math.max(0, r * r - yDist * yDist));
            int inner = (int) Math.floor(r - xDist);

            // Внутренняя часть — полный цвет
            if (inner > 0) {
                ctx.fill(x + inner, y + dy, x + r, y + dy + 1, color);
                ctx.fill(x + w - r, y + dy, x + w - inner, y + dy + 1, color);
                ctx.fill(x + inner, y + h - dy - 1, x + r, y + h - dy, color);
                ctx.fill(x + w - r, y + h - dy - 1, x + w - inner, y + h - dy, color);
            }

            // Пиксель на границе — со сглаживанием
            double edge = (r - xDist) - inner;
            if (edge > 0.01 && inner >= 0) {
                int edgeAlpha = (int) (alpha * edge);
                int edgeColor = (edgeAlpha << 24) | rgb;
                if (inner > 0) {
                    ctx.fill(x + inner - 1, y + dy, x + inner, y + dy + 1, edgeColor);
                    ctx.fill(x + w - inner, y + dy, x + w - inner + 1, y + dy + 1, edgeColor);
                    ctx.fill(x + inner - 1, y + h - dy - 1, x + inner, y + h - dy, edgeColor);
                    ctx.fill(x + w - inner, y + h - dy - 1, x + w - inner + 1, y + h - dy, edgeColor);
                } else {
                    ctx.fill(x, y + dy, x + 1, y + dy + 1, edgeColor);
                    ctx.fill(x + w - 1, y + dy, x + w, y + dy + 1, edgeColor);
                    ctx.fill(x, y + h - dy - 1, x + 1, y + h - dy, edgeColor);
                    ctx.fill(x + w - 1, y + h - dy - 1, x + w, y + h - dy, edgeColor);
                }
            }
        }

        // Верхняя и нижняя горизонтали между углами
        ctx.fill(x + r, y, x + w - r, y + 1, color);
        ctx.fill(x + r, y + h - 1, x + w - r, y + h, color);
    }

    public static void text(DrawContext ctx, TextRenderer tr, String s,
                            int x, int y, int color, boolean shadow) {
        ctx.drawText(tr, styled(s), x, y, color, shadow);
    }

    public static void glowText(DrawContext ctx, TextRenderer tr, String s,
                                int x, int y, int textColor, int glowColor, boolean shadow) {
        Text t = styled(s);
        int[][] offsets = {
                {-2, 0}, {2, 0}, {0, -2}, {0, 2},
                {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
                {-2, -2}, {2, -2}, {-2, 2}, {2, 2}
        };
        for (int[] o : offsets) {
            ctx.drawText(tr, t, x + o[0], y + o[1], glowColor, false);
        }
        ctx.drawText(tr, t, x, y, textColor, shadow);
    }
}
