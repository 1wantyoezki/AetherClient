package me.aether.aetherclient.module;

import me.aether.aetherclient.gui.Theme;

public class Modules {

    public static class MiddleClickFriend extends Module {
        public MiddleClickFriend() {
            super("MiddleClickFriend", Category.COMBAT, "Добавляет в друзья по средней кнопке мыши");
        }
    }

    public static class NameProtect extends Module {
        public NameProtect() {
            super("NameProtect", Category.COMBAT, "Скрывает информацию о себе и других игроках");
        }
    }

    public static class ChatSuffix extends Module {
        public ChatSuffix() {
            super("ChatSuffix", Category.COMBAT, "Добавляет клиент-тег к вашим сообщениям");
        }
    }

    public static class HitMarker extends Module {
        public HitMarker() {
            super("HitMarker", Category.COMBAT, "Показывает удар при попадании по игроку");
        }
    }

    public static class AimTest extends Module {
        public AimTest() {
            super("AimTest", Category.COMBAT, "Silent aim на ближайшего игрока (тест)");
        }
    }

    public static class Sprint extends Module {
        public Sprint() {
            super("Sprint", Category.MOVEMENT, "Автоматически включает спринт");
        }
    }

    public static class NoSlow extends Module {
        public NoSlow() {
            super("NoSlow", Category.MOVEMENT, "Убирает замедление при использовании предметов");
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() {
            super("Fullbright", Category.VISUALS, "Полное освещение мира");
        }
    }

    public static class StorageESP extends Module {
        public StorageESP() {
            super("StorageESP", Category.VISUALS, "Подсвечивает сундуки и хранилища");
        }
    }

    public static class AutoRespawn extends Module {
        public AutoRespawn() {
            super("AutoRespawn", Category.PLAYER, "Автоматически возрождает после смерти");
        }
    }

    public static class FastPlace extends Module {
        public FastPlace() {
            super("FastPlace", Category.PLAYER, "Ускоряет установку блоков");
        }
    }

    public static class KillMessage extends Module {
        public KillMessage() {
            super("KillMessage", Category.MISC, "Сообщает в чат что вас убили");
        }
    }

    public static class AntiAFK extends Module {
        public AntiAFK() {
            super("AntiAFK", Category.MISC, "Не даёт кикнуть за неактивность");
        }
    }

    public static class AccentColor extends Module {
        public static final int[] COLORS = {
                0xFF3B82F6, 0xFFEF4444, 0xFFFACC15, 0xFF92400E, 0xFF6B7280,
                0xFFA855F7, 0xFF06B6D4, 0xFF22C55E, 0xFFEC4899
        };
        public static final String[] COLOR_NAMES = {
                "Синий", "Красный", "Жёлтый",
                "Коричневый", "Серый", "Фиолетовый",
                "Голубой", "Зелёный", "Розовый"
        };
        public static int index = 1;

        public AccentColor() {
            super("AccentColor", Category.CLICKGUI, "Цвет акцента ClickGui");
            Theme.ACCENT = COLORS[index];
        }

        @Override
        public void onClick() {
            index = (index + 1) % COLORS.length;
            Theme.ACCENT = COLORS[index];
        }

        @Override
        public String getDisplayInfo() {
            return COLOR_NAMES[index];
        }
    }
}
