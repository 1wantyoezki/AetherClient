package me.aether.aetherclient.module;

import me.aether.aetherclient.gui.Theme;

public class Modules {

    public static class KillAura extends Module {
        public KillAura() {
            super("KillAura", Category.COMBAT, "Автоматически бьёт ближайшую цель");
            addSetting(new SliderSetting("Range", 3.0f, 1.0f, 6.0f, 0.1f));
            addSetting(new ChoiceSetting("Target", new String[]{"Players", "Mobs", "All"}, 0));
            addSetting(new ChoiceSetting("SprintReset", new String[]{"Smart", "Simple"}, 0));
        }
    }

    public static class AccentColor extends Module {
        public static final int[] COLORS = {
                0xFF3B82F6, 0xFFEF4444, 0xFFFACC15, 0xFF92400E, 0xFF6B7280,
                0xFFA855F7, 0xFF06B6D4, 0xFF22C55E, 0xFFEC4899
        };
        public static final String[] COLOR_NAMES = {
                "Синий", "Красный", "Жёлтый",
                "Коричневый", "Серый", "Фиолетовый",
                "Голубой", "Зелёный", "Розовый"
        };
        public static int index = 1;

        public AccentColor() {
            super("AccentColor", Category.CLICKGUI, "Цвет акцента ClickGui");
            Theme.ACCENT = COLORS[index];
        }

        @Override
        public void onClick() {
            index = (index + 1) % COLORS.length;
            Theme.ACCENT = COLORS[index];
        }

        @Override
        public String getDisplayInfo() {
            return COLOR_NAMES[index];
        }
    }
}
