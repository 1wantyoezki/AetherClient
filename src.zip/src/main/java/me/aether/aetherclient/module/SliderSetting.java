package me.aether.aetherclient.module;

public class SliderSetting extends Setting {
    public float value;
    public final float min, max, step;

    public SliderSetting(String name, float value, float min, float max, float step) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public void setFromPercent(float p) {
        float v = min + (max - min) * p;
        v = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public float getPercent() {
        return (value - min) / (max - min);
    }

    @Override
    public String displayValue() {
        return String.format("%.1f", value);
    }
}
