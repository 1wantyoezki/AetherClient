package me.aether.aetherclient.module;

public class Module {
    public final String name;
    public final Category category;
    public final String description;
    public boolean enabled = false;

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public void onClick() {
        toggle();
    }

    public String getDisplayInfo() {
        return "";
    }
}
