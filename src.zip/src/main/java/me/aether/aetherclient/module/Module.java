package me.aether.aetherclient.module;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final Category category;
    public final String description;
    public boolean enabled = false;
    public int keybind = -1;
    public boolean binding = false;

    private final List<Setting> settings = new ArrayList<>();

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    public void addSetting(Setting s) { settings.add(s); }
    public List<Setting> getSettings() { return settings; }

    public Setting getSetting(String name) {
        for (Setting s : settings) if (s.name.equals(name)) return s;
        return null;
    }

    public void toggle() {
        enabled = !enabled;
        onToggle();
    }

    public void onClick() {
        toggle();
    }

    public void onToggle() {}

    public String getDisplayInfo() {
        return "";
    }
}
