package me.aether.aetherclient.module;

public abstract class Setting {
    public final String name;
    public Setting(String name) { this.name = name; }
    public abstract String displayValue();
}
