package me.aether.aetherclient.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new Modules.KillAura());
        MODULES.add(new Modules.AccentColor());
    }

    public static Module byName(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m;
        return null;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static List<Module> search(String q) {
        String lower = q.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.name.toLowerCase().contains(lower)
                    || m.description.toLowerCase().contains(lower)) {
                out.add(m);
            }
        }
        return out;
    }
}
