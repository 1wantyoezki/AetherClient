package me.aether.aetherclient.module;

public class ChoiceSetting extends Setting {
    public final String[] options;
    public int index;

    public ChoiceSetting(String name, String[] options, int index) {
        super(name);
        this.options = options;
        this.index = index;
    }

    public void next() {
        index = (index + 1) % options.length;
    }

    @Override
    public String displayValue() {
        return options[index];
    }
}
