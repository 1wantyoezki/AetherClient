package me.aether.aetherclient.module;

import me.aether.aetherclient.gui.ClickGuiScreen;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

public class KeybindHandler {
    private static final Set<Integer> held = new HashSet<>();
    private static Module bindingModule = null;

    public static void startBinding(Module m) {
        bindingModule = m;
        m.binding = true;
    }

    public static boolean isBinding() { return bindingModule != null; }

    public static void cancelBinding() {
        if (bindingModule != null) bindingModule.binding = false;
        bindingModule = null;
    }

    public static void onKeyPressed(int key) {
        if (bindingModule != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE) {
                bindingModule.keybind = -1;
            } else {
                bindingModule.keybind = key;
            }
            bindingModule.binding = false;
            bindingModule = null;
            return;
        }

        if (key == GLFW.GLFW_KEY_UNKNOWN) return;
        if (held.contains(key)) return;
        held.add(key);

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen instanceof ClickGuiScreen) return;

        for (Module m : ModuleManager.MODULES) {
            if (m.keybind == key) m.toggle();
        }
    }

    public static void onKeyReleased(int key) {
        held.remove(key);
    }
}
