package me.aether.aetherclient.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    VISUALS("Visuals"),
    PLAYER("Player"),
    MISC("Misc"),
    CLICKGUI("ClickGui");

    public final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }
}
