package me.aether.aetherclient;

import me.aether.aetherclient.gui.ClickGuiScreen;
import me.aether.aetherclient.module.Module;
import me.aether.aetherclient.module.ModuleManager;
import me.aether.aetherclient.rotation.RotationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AetherClient implements ClientModInitializer {
    public static final String NAME = "AetherClient";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);
    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[{}] Initialized", NAME);
        ModuleManager.init();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aetherclient.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "AetherClient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            updateAimTest(client);
        });
    }

    private void updateAimTest(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        Module aimTest = ModuleManager.byName("AimTest");
        if (aimTest == null || !aimTest.enabled) {
            RotationManager.clearTarget();
            return;
        }

        PlayerEntity target = findNearestPlayer(client, 10.0);
        if (target == null) {
            RotationManager.clearTarget();
            return;
        }

        double dx = target.getX() - client.player.getX();
        double dy = (target.getY() + target.getEyeHeight(target.getPose()))
                  - (client.player.getY() + client.player.getEyeHeight(client.player.getPose()));
        double dz = target.getZ() - client.player.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        RotationManager.setTarget(yaw, pitch);
    }

    private PlayerEntity findNearestPlayer(MinecraftClient mc, double range) {
        PlayerEntity nearest = null;
        double minDist = range * range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (!p.isAlive()) continue;
            double d = mc.player.squaredDistanceTo(p);
            if (d < minDist) {
                minDist = d;
                nearest = p;
            }
        }
        return nearest;
    }
}
