package me.aether.aetherclient.rotation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

public class RotationManager {
    private static float currentYaw = 0f;
    private static float currentPitch = 0f;
    private static float targetYaw = 0f;
    private static float targetPitch = 0f;
    private static boolean active = false;
    private static boolean sendingPacket = false;
    private static boolean initialized = false;
    private static float speed = 20f;

    public static void update(MinecraftClient mc) {
        if (mc.player == null) return;

        if (!initialized) {
            currentYaw = mc.player.getYaw();
            currentPitch = mc.player.getPitch();
            initialized = true;
        }

        float destYaw = active ? targetYaw : mc.player.getYaw();
        float destPitch = active ? targetPitch : mc.player.getPitch();

        currentYaw = lerpAngle(currentYaw, destYaw, speed);
        currentPitch = lerpAngle(currentPitch, destPitch, speed);
    }

    private static float lerpAngle(float from, float to, float step) {
        float diff = MathHelper.wrapDegrees(to - from);
        if (Math.abs(diff) <= step) return to;
        return from + Math.signum(diff) * step;
    }

    public static void setTarget(float yaw, float pitch) {
        targetYaw = yaw;
        targetPitch = pitch;
        active = true;
    }

    public static void clearTarget() {
        active = false;
    }

    public static boolean isActive() { return active; }
    public static float getYaw() { return currentYaw; }
    public static float getPitch() { return currentPitch; }
    public static boolean isSendingPacket() { return sendingPacket; }
    public static void setSendingPacket(boolean b) { sendingPacket = b; }
    public static void setSpeed(float s) { speed = s; }
    public static float getSpeed() { return speed; }
}
